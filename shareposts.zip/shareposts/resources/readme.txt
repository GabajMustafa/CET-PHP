This folder does not contain any application files

-database.sql
Import this into your database to create the posts and users tables